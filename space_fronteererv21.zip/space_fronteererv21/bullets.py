
import pygame as pg
import math
from math import tan, copysign
from math import pi, hypot, cos, sin, atan2, degrees, radians
from pygame.math import Vector2
from constants import Constants as con
class Bullet(pg.sprite.Sprite):
    def __init__(self, pos, direction):
        super().__init__()
        self.x, self.y = pos
        self.pos = self.x, self.y
        self.dir = direction
        length = math.hypot(*self.dir)
        if length == 0.0:
            self.dir = (0, -1)
        else:
            self.dir = (self.dir[0]/length, self.dir[1]/length)
            angle = math.degrees(math.atan2(-self.dir[1], self.dir[0]))
        angle = math.degrees(math.atan2(-self.dir[1], self.dir[0]))
        self.bullet = pg.Surface((7, 7),7).convert_alpha()
        self.bullet_rect = self.bullet.get_rect(center = self.pos)
        self.bullet.fill((255, 0, 255))
        self.bullet = pg.transform.rotate(self.bullet, angle)
        self.speed = 20
        self.update()
    def update(self):  
        self.pos = (self.pos[0]+self.dir[0]*self.speed, 
                    self.pos[1]+self.dir[1]*self.speed)

    def draw(self, surf):
        bullet_rect = self.bullet.get_rect(center = self.pos)
        con.screen.blit(self.bullet, bullet_rect)
        
class Projectile(pg.sprite.Sprite):
    def __init__(self, pos, direction):
        super().__init__()
        self.x, self.y = pos
        self.pos = self.x, self.y

        self.dir = direction
        length = math.hypot(*self.dir)
        if length == 0.0:
            self.dir = (0, -1)
        else:
            self.dir = (self.dir[0]/length, self.dir[1]/length)
            angle = math.degrees(math.atan2(-self.dir[1], self.dir[0]))
        angle = math.degrees(math.atan2(-self.dir[1], self.dir[0]))
        self.projectile = pg.Surface((10, 6)).convert_alpha()
        self.projectile_rect = self.projectile.get_rect(center = self.pos)
        self.projectile.fill((255, 0, 0))
        self.projectile = pg.transform.rotate(self.projectile, angle)
        self.speed = 20
        self.update()
    def update(self):
        self.pos = (self.pos[0]+self.dir[0]*self.speed, 
                    self.pos[1]+self.dir[1]*self.speed)

    def draw(self, surf):
        projectile_rect = self.projectile.get_rect(center = self.pos)
        con.screen.blit(self.projectile, projectile_rect)
        

