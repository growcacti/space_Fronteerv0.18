import pygame as pg




class Constants:
   
    WHITE = ((255,255,255))
    WIDTH = 1300
    HEIGHT = 800
    screen = pg.display.set_mode((WIDTH, HEIGHT))



