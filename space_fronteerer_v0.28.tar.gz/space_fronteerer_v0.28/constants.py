import pygame as pg




class Constants:
   
    WHITE = ((255,255,255))
    WIDTH = 1300
    HEIGHT = 800
    screen = pg.display.set_mode((WIDTH, HEIGHT))
    MARGINX = 325
    MARGINY = 240
    W = WIDTH
    H = HEIGHT
    HW = W / 2
    QW = W / 4
    HQW = HW + QW
    HH = H /2
    QH = H / 4
    HQH = HH + QH
    
    


