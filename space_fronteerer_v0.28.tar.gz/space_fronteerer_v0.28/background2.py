import pygame as pg



from pygame.locals import *      
import sys
 
# 1200 x 630

W = 300
H = 158
HW = W / 2
HH = H / 2


QW = HW / 4
QH = HH/  4

screen = pg.display.set_mode((1200, 800))
clock = pg.time.Clock()

bg_img = pg.image.load("gx/bg88.png") 




class Subsurf:

    def __init__(self, pos, size, image):
        self.image =image
        self.size = size
        self.pos = pos
        self.w, self.h = self.size
        self.x, self.y = self.pos
        self.make_subrect()

    def make_subrect(self):
        self.rect = pg.Rect(self.image.get_rect())
        self.sub_surf = self.image.subsurface(self.rect)
        self.surf= pg.Surface((20000, 20000))
        self.surf.blit(self.sub_surf, (HW,HH))
      
        return self.sub_surf, self.surf


##    def blit(self, sub_surf, x, y):
##        screen.blit(sub_surf, (self.x, self.y))    
##
i = 0
j = 0
 
pos = (400,800)
size = (HW, HH)

s = Subsurf(pos,size, bg_img)
ss = Subsurf(pos,size, bg_img)
ss2 = Subsurf(pos,size, bg_img)
ss3 = Subsurf(pos,size, bg_img)
#bg_img = pg.transform.scale(bg_img,(width,height))

 
loop = True
while loop:
    screen.fill((0,0,0))
##    screen.blit(bg_img,(i,j))
   
    screen.blit(bg_img,(QW, QH))
    screen.blit(s.sub_surf,(i, j))
    screen.blit(ss.sub_surf,((-i, -j)))
    screen.blit(ss2.sub_surf,(-i, j))
    screen.blit(ss2.sub_surf,(i, -j))
    for event in pg.event.get():
        if event.type == QUIT:
            loop = False
    i += 0.5
    j += 0.5
    pressed = pg.key.get_pressed()
     

    if pressed[pg.K_UP]:
        j-= 1
##        screen.blit(bg_img,(0, height+j))
      
    if pressed[pg.K_DOWN]:
        j += 1
##        screen.blit(bg_img,(0, height+j))
          
    if pressed[pg.K_LEFT]:
        i-= 5
##        screen.blit(bg_img,(width+i, 0))

    if pressed[pg.K_RIGHT]:
        i += 5
##        screen.blit(bg_img,(width + i, 0))     
    pg.display.update()
pg.quit()



                    
